package com.jeff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot0102QuickstartApplicationTests {

	@Test
	void contextLoads() {
	}

}
